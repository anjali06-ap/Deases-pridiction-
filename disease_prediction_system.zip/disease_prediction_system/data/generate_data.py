"""
generate_data.py
-----------------
Generates realistic SYNTHETIC electronic health record (EHR) datasets for:
  1. Heart disease risk prediction  -> data/heart_disease.csv
  2. Diabetes risk prediction        -> data/diabetes.csv

NOTE: These are synthetically generated datasets that mimic the statistical
structure and feature ranges of well-known clinical datasets (UCI Heart
Disease / Pima Indians Diabetes). For a real deployment, replace these with
actual data from:
  - UCI Heart Disease Dataset: https://archive.ics.uci.edu/dataset/45/heart+disease
  - Pima Indians Diabetes Dataset: https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database
  - Or real EHR data (e.g., MIMIC-III/IV, with proper access approval).

Run:
    python generate_data.py
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)

OUT_DIR = os.path.dirname(os.path.abspath(__file__))


def generate_heart_disease_data(n=1000):
    age = np.random.normal(54, 9, n).clip(29, 80).astype(int)
    sex = np.random.binomial(1, 0.68, n)  # 1 = male, 0 = female
    resting_bp = np.random.normal(131, 17, n).clip(90, 200).astype(int)
    cholesterol = np.random.normal(246, 52, n).clip(120, 500).astype(int)
    fasting_bs = np.random.binomial(1, 0.15, n)  # >120 mg/dl
    max_hr = np.random.normal(150, 23, n).clip(70, 210).astype(int)
    exercise_angina = np.random.binomial(1, 0.33, n)
    oldpeak = np.random.exponential(1.0, n).clip(0, 6.2).round(1)
    chest_pain_type = np.random.choice([0, 1, 2, 3], n, p=[0.47, 0.17, 0.28, 0.08])
    st_slope = np.random.choice([0, 1, 2], n, p=[0.13, 0.5, 0.37])

    # Build a latent risk score from clinically plausible relationships
    risk = (
        0.04 * (age - 50)
        + 0.8 * sex
        + 0.02 * (resting_bp - 130)
        + 0.01 * (cholesterol - 240)
        + 0.5 * fasting_bs
        - 0.02 * (max_hr - 150)
        + 0.9 * exercise_angina
        + 0.35 * oldpeak
        + 0.3 * (chest_pain_type == 0).astype(int)
        + 0.4 * (st_slope == 2).astype(int)
        + np.random.normal(0, 1.0, n)  # noise
    )
    prob = 1 / (1 + np.exp(-(risk - risk.mean()) / risk.std()))
    target = np.random.binomial(1, prob)

    df = pd.DataFrame({
        "age": age,
        "sex": sex,
        "chest_pain_type": chest_pain_type,
        "resting_bp": resting_bp,
        "cholesterol": cholesterol,
        "fasting_bs": fasting_bs,
        "max_hr": max_hr,
        "exercise_angina": exercise_angina,
        "oldpeak": oldpeak,
        "st_slope": st_slope,
        "target": target
    })

    # Inject some missing values to simulate real-world EHR sparsity
    for col in ["cholesterol", "resting_bp", "max_hr"]:
        mask = np.random.rand(n) < 0.03
        df.loc[mask, col] = np.nan

    return df


def generate_diabetes_data(n=1000):
    pregnancies = np.random.poisson(2.5, n).clip(0, 15)
    glucose = np.random.normal(120, 32, n).clip(50, 250).astype(int)
    blood_pressure = np.random.normal(72, 12, n).clip(30, 130).astype(int)
    skin_thickness = np.random.normal(20, 10, n).clip(0, 60).astype(int)
    insulin = np.random.exponential(80, n).clip(0, 600).astype(int)
    bmi = np.random.normal(32, 7, n).clip(15, 60).round(1)
    diabetes_pedigree = np.random.exponential(0.47, n).clip(0.08, 2.5).round(3)
    age = np.random.normal(33, 11, n).clip(21, 81).astype(int)

    risk = (
        0.02 * (glucose - 120)
        + 0.05 * (bmi - 32)
        + 0.03 * (age - 33)
        + 1.2 * diabetes_pedigree
        + 0.01 * (blood_pressure - 72)
        + 0.15 * pregnancies
        + np.random.normal(0, 1.0, n)
    )
    prob = 1 / (1 + np.exp(-(risk - risk.mean()) / risk.std()))
    target = np.random.binomial(1, prob)

    df = pd.DataFrame({
        "pregnancies": pregnancies,
        "glucose": glucose,
        "blood_pressure": blood_pressure,
        "skin_thickness": skin_thickness,
        "insulin": insulin,
        "bmi": bmi,
        "diabetes_pedigree": diabetes_pedigree,
        "age": age,
        "target": target
    })

    for col in ["skin_thickness", "insulin", "blood_pressure"]:
        mask = np.random.rand(n) < 0.05
        df.loc[mask, col] = np.nan

    return df


if __name__ == "__main__":
    heart_df = generate_heart_disease_data(1000)
    diabetes_df = generate_diabetes_data(1000)

    heart_path = os.path.join(OUT_DIR, "heart_disease.csv")
    diabetes_path = os.path.join(OUT_DIR, "diabetes.csv")

    heart_df.to_csv(heart_path, index=False)
    diabetes_df.to_csv(diabetes_path, index=False)

    print(f"Heart disease dataset saved: {heart_path} ({len(heart_df)} rows)")
    print(f"Diabetes dataset saved: {diabetes_path} ({len(diabetes_df)} rows)")
    print(f"\nHeart disease target balance:\n{heart_df['target'].value_counts(normalize=True)}")
    print(f"\nDiabetes target balance:\n{diabetes_df['target'].value_counts(normalize=True)}")
