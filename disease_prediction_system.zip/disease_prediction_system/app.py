"""
app.py
------
Flask web app for the Disease Prediction System.
Provides:
  - A simple HTML form UI (/heart, /diabetes)
  - A JSON REST API (/api/predict/<disease>)

Run:
    python app.py
Then open http://localhost:5000 in your browser.
"""

import os
import sys
import joblib
import pandas as pd
from flask import Flask, request, jsonify, render_template

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")

app = Flask(__name__)

MODEL_FILES = {
    "heart": "heart_disease_rf.joblib",
    "diabetes": "diabetes_rf.joblib"
}

FIELD_CONFIG = {
    "heart": [
        {"name": "age", "label": "Age", "type": "number", "min": 18, "max": 100, "default": 50},
        {"name": "sex", "label": "Sex", "type": "select", "options": [("1", "Male"), ("0", "Female")]},
        {"name": "chest_pain_type", "label": "Chest Pain Type", "type": "select",
         "options": [("0", "Typical Angina"), ("1", "Atypical Angina"), ("2", "Non-anginal"), ("3", "Asymptomatic")]},
        {"name": "resting_bp", "label": "Resting Blood Pressure (mmHg)", "type": "number", "min": 80, "max": 220, "default": 130},
        {"name": "cholesterol", "label": "Cholesterol (mg/dl)", "type": "number", "min": 100, "max": 600, "default": 220},
        {"name": "fasting_bs", "label": "Fasting Blood Sugar > 120 mg/dl", "type": "select", "options": [("0", "No"), ("1", "Yes")]},
        {"name": "max_hr", "label": "Max Heart Rate Achieved", "type": "number", "min": 60, "max": 220, "default": 150},
        {"name": "exercise_angina", "label": "Exercise-Induced Angina", "type": "select", "options": [("0", "No"), ("1", "Yes")]},
        {"name": "oldpeak", "label": "ST Depression (Oldpeak)", "type": "number", "step": "0.1", "min": 0, "max": 7, "default": 1.0},
        {"name": "st_slope", "label": "ST Slope", "type": "select", "options": [("0", "Upsloping"), ("1", "Flat"), ("2", "Downsloping")]},
    ],
    "diabetes": [
        {"name": "pregnancies", "label": "Number of Pregnancies", "type": "number", "min": 0, "max": 20, "default": 1},
        {"name": "glucose", "label": "Plasma Glucose (mg/dl)", "type": "number", "min": 40, "max": 300, "default": 110},
        {"name": "blood_pressure", "label": "Diastolic Blood Pressure (mmHg)", "type": "number", "min": 30, "max": 140, "default": 72},
        {"name": "skin_thickness", "label": "Skin Thickness (mm)", "type": "number", "min": 0, "max": 100, "default": 20},
        {"name": "insulin", "label": "Serum Insulin (mu U/ml)", "type": "number", "min": 0, "max": 900, "default": 80},
        {"name": "bmi", "label": "BMI", "type": "number", "step": "0.1", "min": 10, "max": 70, "default": 28.0},
        {"name": "diabetes_pedigree", "label": "Diabetes Pedigree Function", "type": "number", "step": "0.01", "min": 0, "max": 3, "default": 0.4},
        {"name": "age", "label": "Age", "type": "number", "min": 18, "max": 100, "default": 33},
    ]
}

_model_cache = {}


def get_model(disease):
    if disease not in _model_cache:
        path = os.path.join(MODEL_DIR, MODEL_FILES[disease])
        if not os.path.exists(path):
            return None
        _model_cache[disease] = joblib.load(path)
    return _model_cache[disease]


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/<disease>")
def disease_form(disease):
    if disease not in FIELD_CONFIG:
        return "Unknown disease type", 404
    artifact = get_model(disease)
    metrics = artifact["metrics"] if artifact else None
    return render_template(
        "form.html",
        disease=disease,
        disease_title="Heart Disease" if disease == "heart" else "Diabetes",
        fields=FIELD_CONFIG[disease],
        metrics=metrics,
        result=None
    )


@app.route("/<disease>/predict", methods=["POST"])
def predict_form(disease):
    if disease not in FIELD_CONFIG:
        return "Unknown disease type", 404

    artifact = get_model(disease)
    if artifact is None:
        return f"Model not trained yet. Run: python src/train_model.py --disease {disease}", 500

    model = artifact["model"]
    feature_names = artifact["feature_names"]

    patient = {}
    for field in FIELD_CONFIG[disease]:
        val = request.form.get(field["name"])
        patient[field["name"]] = float(val) if field["type"] == "number" else int(val)

    df = pd.DataFrame([patient])[feature_names]
    proba = float(model.predict_proba(df)[0, 1])
    prediction = "High Risk" if proba >= 0.5 else "Low Risk"

    result = {"prediction": prediction, "probability": round(proba * 100, 2)}

    return render_template(
        "form.html",
        disease=disease,
        disease_title="Heart Disease" if disease == "heart" else "Diabetes",
        fields=FIELD_CONFIG[disease],
        metrics=artifact["metrics"],
        result=result,
        submitted_values=patient
    )


@app.route("/api/predict/<disease>", methods=["POST"])
def api_predict(disease):
    if disease not in MODEL_FILES:
        return jsonify({"error": "Unknown disease type"}), 404

    artifact = get_model(disease)
    if artifact is None:
        return jsonify({"error": "Model not trained yet"}), 500

    model = artifact["model"]
    feature_names = artifact["feature_names"]

    data = request.get_json(force=True)
    try:
        df = pd.DataFrame([data])[feature_names]
    except KeyError as e:
        return jsonify({"error": f"Missing field: {e}"}), 400

    proba = float(model.predict_proba(df)[0, 1])
    prediction = int(proba >= 0.5)

    return jsonify({
        "disease": disease,
        "prediction": "High Risk" if prediction == 1 else "Low Risk",
        "probability": round(proba, 4)
    })


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
