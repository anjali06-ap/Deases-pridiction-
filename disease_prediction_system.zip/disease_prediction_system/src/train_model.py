"""
train_model.py
---------------
Trains a Random Forest classifier for either heart disease or diabetes
prediction, with:
  - preprocessing pipeline (imputation + scaling)
  - class imbalance handling (class_weight='balanced')
  - hyperparameter search (RandomizedSearchCV)
  - evaluation (accuracy, precision, recall, F1, ROC-AUC, confusion matrix)
  - feature importance plot
  - saved model artifact (joblib)

Usage:
    python train_model.py --disease heart
    python train_model.py --disease diabetes
"""

import argparse
import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, RandomizedSearchCV, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report, RocCurveDisplay
)

from preprocess import build_preprocessor

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
MODEL_DIR = os.path.join(BASE_DIR, "models")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")

DISEASE_CONFIG = {
    "heart": {
        "csv": "heart_disease.csv",
        "target": "target",
        "model_file": "heart_disease_rf.joblib"
    },
    "diabetes": {
        "csv": "diabetes.csv",
        "target": "target",
        "model_file": "diabetes_rf.joblib"
    }
}


def load_data(disease):
    cfg = DISEASE_CONFIG[disease]
    path = os.path.join(DATA_DIR, cfg["csv"])
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Run `python data/generate_data.py` first."
        )
    df = pd.read_csv(path)
    X = df.drop(columns=[cfg["target"]])
    y = df[cfg["target"]]
    return X, y, cfg


def train(disease):
    print(f"\n{'='*60}\nTraining Random Forest for: {disease.upper()} DISEASE PREDICTION\n{'='*60}")

    X, y, cfg = load_data(disease)
    feature_names = X.columns.tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor = build_preprocessor(feature_names)

    pipeline = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            random_state=42, class_weight="balanced"
        ))
    ])

    # Hyperparameter search space
    param_dist = {
        "classifier__n_estimators": [100, 200, 300, 400],
        "classifier__max_depth": [None, 5, 10, 15, 20],
        "classifier__min_samples_split": [2, 5, 10],
        "classifier__min_samples_leaf": [1, 2, 4],
        "classifier__max_features": ["sqrt", "log2"]
    }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    search = RandomizedSearchCV(
        pipeline,
        param_distributions=param_dist,
        n_iter=25,
        scoring="roc_auc",
        cv=cv,
        random_state=42,
        n_jobs=-1,
        verbose=0
    )

    print("Running hyperparameter search (RandomizedSearchCV, 5-fold CV)...")
    search.fit(X_train, y_train)

    best_model = search.best_estimator_
    print(f"\nBest params: {search.best_params_}")
    print(f"Best CV ROC-AUC: {search.best_score_:.4f}")

    # Evaluate on held-out test set
    y_pred = best_model.predict(X_test)
    y_proba = best_model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba)
    }

    print("\n--- Test Set Performance ---")
    for k, v in metrics.items():
        print(f"{k:>10}: {v:.4f}")

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=["No Disease", "Disease"]))

    cm = confusion_matrix(y_test, y_pred)
    print("Confusion Matrix:")
    print(cm)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Confusion matrix plot
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1]); ax.set_xticklabels(["No Disease", "Disease"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["No Disease", "Disease"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
    ax.set_title(f"Confusion Matrix - {disease.title()}")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im)
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, f"{disease}_confusion_matrix.png"), dpi=150)
    plt.close(fig)

    # ROC curve
    fig, ax = plt.subplots(figsize=(5, 4))
    RocCurveDisplay.from_predictions(y_test, y_proba, ax=ax)
    ax.set_title(f"ROC Curve - {disease.title()} (AUC={metrics['roc_auc']:.3f})")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, f"{disease}_roc_curve.png"), dpi=150)
    plt.close(fig)

    # Feature importance plot
    rf = best_model.named_steps["classifier"]
    importances = rf.feature_importances_
    order = np.argsort(importances)[::-1]
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.barh([feature_names[i] for i in order][::-1], importances[order][::-1], color="#2563eb")
    ax.set_xlabel("Importance")
    ax.set_title(f"Feature Importance - {disease.title()} Disease Prediction")
    fig.tight_layout()
    fig.savefig(os.path.join(OUTPUT_DIR, f"{disease}_feature_importance.png"), dpi=150)
    plt.close(fig)

    # Save model artifact
    os.makedirs(MODEL_DIR, exist_ok=True)
    model_path = os.path.join(MODEL_DIR, cfg["model_file"])
    joblib.dump({
        "model": best_model,
        "feature_names": feature_names,
        "metrics": metrics,
        "best_params": search.best_params_
    }, model_path)
    print(f"\nModel saved to: {model_path}")
    print(f"Plots saved to: {OUTPUT_DIR}/")

    return best_model, metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train disease prediction Random Forest model")
    parser.add_argument("--disease", choices=["heart", "diabetes", "both"], default="both",
                         help="Which disease model to train")
    args = parser.parse_args()

    if args.disease == "both":
        for d in ["heart", "diabetes"]:
            train(d)
    else:
        train(args.disease)
