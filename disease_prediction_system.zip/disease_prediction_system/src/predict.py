"""
predict.py
----------
Load a trained model and predict disease risk for a new patient record.

Usage (example):
    python predict.py --disease heart
"""

import argparse
import os
import joblib
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "models")

MODEL_FILES = {
    "heart": "heart_disease_rf.joblib",
    "diabetes": "diabetes_rf.joblib"
}

# Example patient records (replace with real input, e.g. from a form/API)
EXAMPLE_PATIENTS = {
    "heart": {
        "age": 61, "sex": 1, "chest_pain_type": 0, "resting_bp": 148,
        "cholesterol": 275, "fasting_bs": 1, "max_hr": 118,
        "exercise_angina": 1, "oldpeak": 2.4, "st_slope": 2
    },
    "diabetes": {
        "pregnancies": 4, "glucose": 158, "blood_pressure": 78,
        "skin_thickness": 32, "insulin": 145, "bmi": 34.5,
        "diabetes_pedigree": 0.62, "age": 44
    }
}


def load_model(disease):
    path = os.path.join(MODEL_DIR, MODEL_FILES[disease])
    if not os.path.exists(path):
        raise FileNotFoundError(f"{path} not found. Train the model first with train_model.py")
    return joblib.load(path)


def predict_patient(disease, patient_dict):
    artifact = load_model(disease)
    model = artifact["model"]
    feature_names = artifact["feature_names"]

    df = pd.DataFrame([patient_dict])[feature_names]
    proba = model.predict_proba(df)[0, 1]
    prediction = model.predict(df)[0]

    return {
        "prediction": "High Risk" if prediction == 1 else "Low Risk",
        "probability": round(float(proba), 4)
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Predict disease risk for a patient")
    parser.add_argument("--disease", choices=["heart", "diabetes"], required=True)
    args = parser.parse_args()

    patient = EXAMPLE_PATIENTS[args.disease]
    result = predict_patient(args.disease, patient)

    print(f"\nPatient input ({args.disease}):")
    for k, v in patient.items():
        print(f"  {k}: {v}")

    print(f"\nPrediction: {result['prediction']}")
    print(f"Probability of disease: {result['probability']*100:.2f}%")
