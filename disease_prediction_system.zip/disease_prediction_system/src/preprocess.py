"""
preprocess.py
-------------
Shared preprocessing pipeline: missing value imputation + scaling.
Uses sklearn Pipeline so the exact same transforms are applied at
train time and prediction time (avoids train/serve skew).
"""

from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer


def build_preprocessor(numeric_features):
    """
    Builds a ColumnTransformer that:
      - imputes missing numeric values with the median
      - scales numeric values (helps if comparing to non-tree models later)
    """
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, numeric_features)
    ])

    return preprocessor
